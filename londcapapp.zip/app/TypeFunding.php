<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeFunding extends Model
{
    //
}
