<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterestedIn extends Model
{
    //
    protected $table = 'interested_in';
}
