
    <title>Londcap</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/chosen.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
  <!--   <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(url('js/select2.min.js')); ?>"></script> -->
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(url('js/bootstrap-select.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/chosen.jquery.js')); ?>"></script>
    
    <?php /**PATH /home/admin/web/londcap-app.com/public_html/resources/views/frontend/include/user-head.blade.php ENDPATH**/ ?>