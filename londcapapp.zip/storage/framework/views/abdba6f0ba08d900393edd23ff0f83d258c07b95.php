
<?php $__env->startSection('content'); ?>
<style type="text/css">
  .padding{
    padding: 100px ; 
  }
</style>
    <section class="inner_pages">
        <div class="container">
            <div class="row">
                <div class="col col-12 text-center padding">

                   <h3>Your email is not verified. <br> Please check your mail inbox/spam box to verify the email</h3>
                   
                </div>
            </div>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/londcap-app.com/public_html/resources/views/frontend/emailnotverified.blade.php ENDPATH**/ ?>