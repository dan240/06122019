<footer class="app-footer">
      <div>
        <a href="https://www.crowdfunder.com/">LondCap</a>
        <span>&copy; 2024 LondCap.</span>
      </div>
      <div class="ml-auto">
        <span>Powered by</span>
        <a href="https://www.crowdfunder.com/">LondCap</a>
      </div>
    </footer><?php /**PATH /home/admin/web/londcap-app.com/public_html/resources/views/backend/include/footer.blade.php ENDPATH**/ ?>