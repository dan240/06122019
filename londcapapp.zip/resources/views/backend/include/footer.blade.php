<footer class="app-footer">
  <div>
    <span>&copy; <?php echo date("Y"); ?> LondCap.</span>
  </div>
</footer>