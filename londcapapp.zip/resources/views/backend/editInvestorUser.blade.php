@extends('layouts.admin')
@section('content')

<div class="container-fluid">
	<div class="row" style="padding:10px;">
        <div class="col-md-6">
          <span style="font-size: 20px;">User Info</span>
        </div>
        <div class="col-md-6 text-right">
          
        </div>
     	</div>
</div>
@endsection