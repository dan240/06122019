@extends('layouts.home')
@section('content')
    <section class="inner-pages fundraising">
        <div class="container">
            <div class="row">
<h4 class="text-center">Choose the best solution for you!</h4>
                <div class="columns">
 
</div>

<div class="columns">
  <ul class="price">
    <li class="header">
      <p>You have reached daily free number of messages, if you wish unlimited please subscrive by paypal.</p></li>
    <li class="grey"><a href="#" class="button">Select Plus</a></li>
    <li><strong>$49.99/month*</strong></li>
     <li><i class="fas fa-check"></i> Lorem Ipsum is simply dummy text lorem Ipsum is simply</li>
    <li><i class="fas fa-check"></i> Lorem Ipsum is simply dummy text lorem Ipsum </li>
    <li><i class="fas fa-check"></i> Lorem Ipsum is simply dummy text lorem Ipsum is simply</li>
       <li><i class="fas fa-check"></i> Lorem Ipsum is simply dummy text lorem Ipsum is simply</li>
  </ul>
</div>

<div class="columns">
 
</div>

            </div>
        </div>
    </section>
     @endsection